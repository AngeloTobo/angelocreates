# Angelo Creates – 3D Art Portfolio

This is a ready-to-deploy GitHub Pages site to showcase your 3D artwork using an interactive viewer.

## 💫 What's Included
- `index.html` with <model-viewer> to view `.glb` files
- Folder structure for your 3D models
- Basic layout and styling

## 🛸 Live Example
After uploading to GitHub, your site will be live at:
`https://yourusername.github.io`

## ⚠️ License
All artwork and models in this repository are © 2025 Angelo Creates.
Do not reuse, copy, or redistribute without written permission.
